# AvaliaFlix
Projeto da disciplina Técnicas de Programação 1, cuja finalidade é aplicar conceitos da programação orientada a objetos na linguagem Java.

AvaliaFlix é um sistema que facilita o gerenciamento pessoal de mídias audiovisuais. A proposta é permitir que o usuário faça o acompanhamento de séries e filmes, com avaliações, comentários, adição a uma lista de favoritos, bem como ajudar a organizar as preferências e facilitar a escolha do que assistir futuramente.
